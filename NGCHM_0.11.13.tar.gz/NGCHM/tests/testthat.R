library(testthat)
library(NGCHM)

test_check("NGCHM")
